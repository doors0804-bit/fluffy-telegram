const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const PORT = process.env.PORT || 8080;
const HTML = path.join(__dirname, '공_시뮬레이터_수정본_(155)회.html');
const server = http.createServer((req,res)=>{
  if(req.url==='/' || req.url==='/index.html'){
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});
    return fs.createReadStream(HTML).pipe(res);
  }
  res.writeHead(404); res.end('Not found');
});
const wss = new WebSocket.Server({server});
const rooms = new Map();
function send(ws,msg){if(ws&&ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(msg));}
wss.on('connection',ws=>{
  ws.room=null; ws.role=null;
  ws.on('message',raw=>{
    let m; try{m=JSON.parse(raw)}catch(e){return}
    if(m.type==='join'){
      const room=String(m.room||'').toUpperCase();
      if(!room)return;
      let r=rooms.get(room);
      if(!r){r={host:null,guest:null};rooms.set(room,r)}
      if(m.role==='host'){if(r.host){send(ws,{type:'error',message:'이미 사용 중인 방이야.'});return}r.host=ws}
      else {if(r.guest){send(ws,{type:'error',message:'방이 꽉 찼어.'});return}if(!r.host){send(ws,{type:'error',message:'존재하지 않는 방이야.'});return}r.guest=ws}
      ws.room=room;ws.role=m.role;send(ws,{type:r.host&&r.guest?'connected':'waiting',room});
      if(r.host&&r.guest){send(r.host,{type:'connected'});send(r.guest,{type:'connected'})}
      return;
    }
    if(!ws.room)return; const r=rooms.get(ws.room); if(!r)return;
    const peer=ws===r.host?r.guest:r.host;
    if(m.type==='choice'){send(peer,{type:'peerChoice',choice:m.choice});return}
    if(m.type==='ready'){return}
    if(m.type==='start'){send(peer,{type:'start',self:m.peer,peer:m.self});return}
    if(m.type==='state'){send(peer,m);return}
    if(m.type==='end'){send(peer,m);return}
  });
  ws.on('close',()=>{if(!ws.room)return;const r=rooms.get(ws.room);if(!r)return;const peer=ws===r.host?r.guest:r.host;send(peer,{type:'error',message:'친구와의 연결이 끊어졌어.'});if(r.host===ws)r.host=null;if(r.guest===ws)r.guest=null;if(!r.host&&!r.guest)rooms.delete(ws.room);});
});
server.listen(PORT,()=>console.log(`Online battle server: http://localhost:${PORT}`));
